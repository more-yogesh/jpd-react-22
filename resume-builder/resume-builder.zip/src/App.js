import logo from './logo.svg';
import './App.css';
import Product from './component/product/product.compoent'
import Counter from './component/counter/couter';

const App = () => {
  return (
    <div>
      <Product/>
      <Counter/>
    </div>
  );
}

export default App;
