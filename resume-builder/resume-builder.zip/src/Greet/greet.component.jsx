
const Greet = () => {
    return (
        <div>
            <h1>Hey, I am Greet!!!</h1>
            <p>Hey, I am Greet!!!</p>
        </div>
    )
}

export default Greet